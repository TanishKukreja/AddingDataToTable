package practice;
class Aria{
    int lenght;
    int breadth;
    Aria(int lenght,int breadth){
        this.breadth=breadth;
        this.lenght=lenght;
    }
    public void getArea(){
        int area =lenght*breadth;
        System.out.println("Area is "+ area);
    }

}
public class Encapsulation {
    public static void main(String[] args){
        Aria rectangle=new Aria(2,3);
        rectangle.getArea();
    }
}
