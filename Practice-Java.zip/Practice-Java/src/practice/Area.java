package practice;

import java.util.Scanner;

public class Area {
    public static void main(String[] args) {
        int length;
        int breadth;
        Scanner lengthObj = new Scanner(System.in);
        System.out.println("Enter Length");
        length = lengthObj.nextInt();
        System.out.println("Enter breadth");
        breadth = lengthObj.nextInt();
        int area = length * breadth;
        System.out.println("Area is " + area);
    }
}
