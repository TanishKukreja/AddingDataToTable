package practice;
class threads{
void run (){
    System.out.println("Thread is running inside");
}
}
public class neww extends threads{
    public static void main(String[] args){
        neww thread=new neww();
        thread.run();
        System.out.println("This code is running outside fof threads");
    }


}
