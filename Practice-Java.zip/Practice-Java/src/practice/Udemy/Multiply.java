package practice.Udemy;

public class Multiply {

    public int multiply(int num1, int num2) {
        return num1 * num2;

    }

    public double multiply(double x, double y, double z) {
        return x + y + z;

    }

    class Main {
        public static void main(String[] args) {
            Multiply result = new Multiply();
            int prod1 = result.multiply(12, 123);
            System.out.println("Result of product is" + prod1);

            double prod2 = result.multiply(2312.3, 32, 1.2);
            System.out.println("Result of product is" + prod2);


        }
    }
}