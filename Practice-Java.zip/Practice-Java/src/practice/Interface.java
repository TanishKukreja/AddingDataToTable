package practice;

interface Person {
final int A =10;
void display();
        }
public class Interface implements Person {
    @Override
    public void display() {
        System.out.println("Geek");
    }
    public static void main(String[] args){
        Interface i=new Interface();
        i.display();
        System.out.println(A);
    }
}
