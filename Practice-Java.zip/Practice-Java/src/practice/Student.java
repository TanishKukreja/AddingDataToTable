package practice;

public class Student {
    int id;
    String name;
    float height;
    int weight;

    Student(int newId, String newName, float newHeight, int newWeight) {
        id = newId;
        name = newName;
        height = newHeight;
        weight = newWeight;

    }

    public static void main(String[] args) {
        Student s = new Student(18, "Tanish", 5.11f, 72);
        Student s2 = new Student(7, "MS", 5.8f, 78);
        System.out.println(s.id);
        System.out.println(s2);
    }

}

