package practice;

import java.util.ArrayList;
import java.util.List;

public class ArrayElement {
    public static void main(String[] args){
        List<Integer> al=new ArrayList<>();
        al.add(12);
        al.add(134);
        al.add(1);
        System.out.println(al);
        al.remove(1);
        System.out.println(al);
    }

}
