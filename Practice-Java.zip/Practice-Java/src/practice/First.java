package practice;
public class First {
    public void fullThrotle(){
        System.out.println("Run Fast");
    }
    public void speed(int maxSpeed){
        System.out.println("max speed is "+ maxSpeed);
    }
    public String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static void main(String[] args) {
        System.out.println("These all are methods");
        First methodObj=new First();
        methodObj.fullThrotle();
        methodObj.speed(20);
        methodObj.setName("Tanish is my name");
       System.out.println(methodObj.getName());
    }
}

