package practice;

import java.io.IOException;

public class TestException {
    void m1() throws IOException {
        throw new java.io.IOException("Device error");
    }

    void n1() throws IOException {
        m1();
    }

    void p1() {
        try {
            n1();
        } catch (Exception e) {
            System.out.println("Exception Handled");
        }
    }

    public static void main(String[] args) {
        TestException obj = new TestException();
        obj.p1();
        System.out.println("Normal Flow");

    }
}
