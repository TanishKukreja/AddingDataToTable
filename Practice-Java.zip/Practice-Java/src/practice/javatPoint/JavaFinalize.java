package practice.javatPoint;

public class JavaFinalize {
    public static void main(String[] args){

    }
}
