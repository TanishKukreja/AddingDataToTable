package practice;
import java.util.Scanner;

public class ScannerJava {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Username");
        String username=sc.nextLine();
        if(username.isEmpty()){
            System.out.println("Username is empty. Mention it");

        } else{
            System.out.println("Username is "+ username);
            System.out.println("Thanks");
        }
    }
}
