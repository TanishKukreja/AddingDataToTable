package practice;

public class Inheritance {
    protected String brand ="Ford";

    public void horn(){
        System.out.println("teee");
    }
}
 class Car extends Inheritance{
    private String modelName="Mustang";
    public static void main(String[] args){
        Car myCar=new Car();
        myCar.horn();
        System.out.println(myCar.modelName+myCar.brand);
    }

 }
