package practice;



public class AreaMethod {
    int length;
    int breadth;
    AreaMethod(int l, int b){
        length = l;
        breadth = b;
    }
    public int setDim(){
        int results = length * breadth;
        return results;
    }
    public void getArea(){
        System.out.println("Area = " +  setDim());
    }
    public static void main(String []args){
        AreaMethod x =new AreaMethod(6,5);
        x.getArea();

    }
}