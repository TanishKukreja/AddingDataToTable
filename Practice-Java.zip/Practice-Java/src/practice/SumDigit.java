package practice;

import java.util.Scanner;

public class SumDigit {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter word which u want to count");
        String word = sc.nextLine();
        System.out.println(word + " : This is your word");
        System.out.println("Count of words are "+CountWords(word));
        System.out.println("Enter number");
        int number = sc.nextInt();
        System.out.println(number + " : This is your number");
        System.out.println(sumDigits(number) + " : This is your sum of number");

    }

    public static int sumDigits(long n) {
        int sum = 0;

        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        return sum;
    }

    public static int CountWords(String str){
        int count = 0;
        if (!(" ".equals(str.substring(0, 1))) || !(" ".equals(str.substring(str.length() - 1))))
        {
            for (int i = 0; i < str.length(); i++)
            {
                if (str.charAt(i) == ' ')
                {
                    count++;
                }
            }
            count = count + 1;
        }
        return count; // returns 0 if string starts or ends with space " ".
    }
}

