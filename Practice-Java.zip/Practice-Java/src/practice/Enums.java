package practice;

enum Level {
    LOW, HIGH, MEDIUM;
}

public class Enums {
    public static void main(String[] args) {
        Level myLevel = Level.LOW;
        System.out.println(myLevel);

    }
}
