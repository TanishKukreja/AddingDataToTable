package practice.Udemy;


public class Dsa {
    public static void main(String[] args){
        int[] array=new int[10];
        System.out.println("Array before adding data");
        display(array);
        // Element Addition
        for(int k=0;k<array.length;k++){
            array[k]=k;
        System.out.println("Addding "+k+" at index "+k);
        }
        System.out.println();
    }

    private static void display(int[] array) {

      //  for(int i=0;i<array.length;i++){

     //   }
    }
}
