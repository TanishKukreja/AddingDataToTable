package practice.asigra;

class Car {
    void safety() {
        System.out.println("Seatbelts Must");
    }
}
class Bike extends Car {
    void safety() {
        System.out.println("Helmet must");
    }
}

public class MethodOverriding {
    public static void main(String[] args) {
        Bike myBike = new Bike();
        Car myCar = new Car();
        myBike.safety();
        myCar.safety();

    }
}
