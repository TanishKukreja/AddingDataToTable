package practice;

public class Getters {
    private String name;

    public String getName(){
        return name;
    }
    public void setName(String newName){
        this.name=newName;
    }
    public static void main(String[] args){
        First myObj=new First();
        myObj.setName("Tanish");
        System.out.println(myObj.getName());
        // next code

        Getters myObject= new Getters();
        myObject.setName("Hey  I am Tanish");
        System.out.println(myObject.getName());


    }
}
