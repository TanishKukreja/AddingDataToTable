package practice.Udemy;

public class LoanApproval {
    static boolean ifStatement() {
        boolean approved = false;
        int age = 45;
        int salary = 5200;
        boolean hasBadRecord = false;

        if (age >= 21 && age < 45 && salary >= 40000) {
            approved = true;
            System.out.println("Loan is approved");

        } else if (age >= 45 && age <= 55 && salary >= 40000) {
            System.out.println("Loan need to verified by Senior department");

        } else if (hasBadRecord) {
            System.out.println("Candidate have bad record so loan is rejected");

        } else {
            System.out.println("Loan rejected");
        }
        return approved;
    }

    public static void main(String[] args) {

        ifStatement();
    }
}
