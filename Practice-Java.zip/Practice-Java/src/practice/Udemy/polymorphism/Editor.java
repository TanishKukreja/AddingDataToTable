package practice.Udemy.polymorphism;

public class Editor  extends Staff{
    public void printUserType() {
        System.out.println("Editor");
    }
    public void approveReview() {

    }
}
