package practice.javatPoint;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class FileHandle {
    public static void main(String[] args){
        PrintWriter pw;
        try{
            pw= new PrintWriter("Tanish.txt");
            pw.println("hi iam wrritten");
            System.out.println("Success");
        }
        catch (FileNotFoundException f){
            System.out.println(f);
            System.out.println("After exception");

        }
        System.out.println("After checking");
    }
}
