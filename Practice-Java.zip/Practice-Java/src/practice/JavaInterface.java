package practice;

interface Janwar{
    public void animalSound();
    public void sleep();
}
class Horse implements Janwar{


    @Override
    public void animalSound() {
        System.out.println("hee-hee");
    }

    @Override
    public void sleep() {
        System.out.println("sinhh");
    }
}
public interface JavaInterface {
    public static void main(String[] args) {


        Horse myHorse = new Horse();
        myHorse.sleep();
        myHorse.animalSound();
    }
}
