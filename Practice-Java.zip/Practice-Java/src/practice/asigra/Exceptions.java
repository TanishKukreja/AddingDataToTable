package practice.asigra;

public class Exceptions {
    public static void main(String[] abc) {

        int[] number = {1, 2, 3, 5};
        try {
            System.out.println(number[1]);
            System.out.println(number[23]);
        } catch (Exception e) {
            System.out.println("Something went wrong");
        } finally {
            System.out.println("This is code by finally");
        }
    }
}


