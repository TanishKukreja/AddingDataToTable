package practice;

import java.util.ArrayList;
import java.util.HashMap;

public class Ifelse {
    public static void main(String[] args) {
        // for-each array
        int[] array1 = {1, 2, 3, 4, 5, 6, 7, 8};
        for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i]);
        }
        for (int i : array1) {

            System.out.print((i));
        }
        HashMap<String, String> brandsCars = new HashMap<>();
        brandsCars.put("Hyundai", "Creta");
        brandsCars.put("Maruti", "Brezza");
        for (String j : brandsCars.keySet()) {
            System.out.println(j);
        }
        System.out.println(brandsCars.get("Maruti"));
        System.out.println(brandsCars);
        ArrayList<String> cars = new ArrayList<>();
        cars.add("Audi");
        cars.add("Bmw");
        cars.add("Merc");
        int time = 18;
        if (time < 18) {
            System.out.println("Good day.");
        }
        if (time == 18) {
            System.out.println("Good evening.");
        } else {
            System.out.println("no");
        }
        System.out.println("hello");
        cars.set(0, "Audi to q7");
        System.out.println(cars.get(0));
        for (String i : cars) {
            System.out.println(i);
        }
    }
}