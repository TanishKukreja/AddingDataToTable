package practice.javatPoint;

public class Exceptions {
    public static void main(String[] args){
    //    String s=null;
      //  System.out.println(s.length());
        try{
            int number=100/0;
            System.out.println("This is not exception");
            System.out.println(number);
        }
        catch (ArithmeticException e){
         System.out.println("This is exception");
            System.out.println(e);
        }
        System.out.println("Code is complete");
    }
}
