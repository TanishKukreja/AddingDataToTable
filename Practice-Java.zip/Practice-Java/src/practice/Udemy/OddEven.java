package practice.Udemy;

import java.util.Scanner;

public class OddEven {

    Scanner sc = new Scanner(System.in);
    boolean result = true;

    public void checkOddEven() {
        System.out.println("Enter integer which u want to check");
        int number = sc.nextInt();
        if (number % 2 == 0) {
            System.out.println(true+" This is even");
        } else {
            System.out.println(false+" This is odd");
        }
    }

      public void  isVowel() {
        System.out.println("Enter character which u want to check for vowel");
    //    char  character =
        String vowels = sc.nextLine();;
        String phrase = vowels.toLowerCase();
        for (int i = 0; i < phrase.length(); i++) {
            if (vowels.indexOf(phrase.charAt(i)) == -1)
                System.out.println(false);
        }
          System.out.println(true);

    }
     public void isConsonent(){
        System.out.println(" Enter characther for conso check");
        char conso=sc.next().charAt(0);
        try{
        if(conso=='a' || conso=='e' || conso=='i' || conso=='o' || conso=='u'){
            System.out.println(conso+" No this is not consonent");
        }

        else{
            System.out.println(conso+" this is consonent");
        }
        }
        catch (Exception e){

            System.out.println("Something went wrong");
        }

     }

    public static void main(String[] args) {
        OddEven obj = new OddEven();
        obj.checkOddEven();
        obj.isVowel();
        obj.isConsonent();

    }
}
