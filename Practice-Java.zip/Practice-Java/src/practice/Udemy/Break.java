package practice.Udemy;

public class Break {
     static void labledBreak(){
         int num=0;
       outermost:  for(int i=0;i<10;i++){
             for(int j=0;j<10;j++){
               if(i==5 && j==6){
                   break outermost;
               }
               num++;
             }
         }

         for(int k=0;k<4;k++){

             if(k==2)
             continue;
             System.out.println(k);
         }
         System.out.println(num);
     }
    public static void main(String[] args){
             labledBreak();
    }
}
