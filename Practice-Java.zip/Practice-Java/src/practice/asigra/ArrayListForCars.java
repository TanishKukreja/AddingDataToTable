package practice.asigra;
import java.util.ArrayList;
import java.util.Collections;

public class ArrayListForCars {
    public static void main(String[] args){
        ArrayList<String>cars=new ArrayList<String>();
        cars.add("VW");
        cars.add("Skoda");
        cars.add("Mahindra");
        cars.add("Tata");
        cars.remove(1);
        System.out.println(cars.size());
        Collections.sort(cars);
        for(String i:cars){
            System.out.println(i);
        }

    }
}
