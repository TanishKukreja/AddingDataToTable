package practice;
class Encap{
    private String name;
    private int rollno;
    private int age;
    public int getRollno(){
        return rollno;
    }
    public int getAge(){
        return age;
    }
    public String getName(){
        return name;
    }
    public void setName(String myName){
        name=myName;
    }
    public void setRollno(int myRoll){
        rollno =myRoll;
    }
    public void setAge(int myAge){
        age=myAge;
    }
}
public class EncapAdvance {
    public static void main(String[] args){
        Encap myObj=new Encap();
        myObj.setAge(21);
        myObj.setName("Tanish");
        myObj.setRollno(4445);
        System.out.println("My name is "+myObj.getName()+" I am "+myObj.getAge()+" years old "+"And my roll no is "+myObj.getRollno());
    }


}
