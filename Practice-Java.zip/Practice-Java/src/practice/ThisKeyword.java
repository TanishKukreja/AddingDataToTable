package practice;

import java.awt.*;

public class ThisKeyword {


    int a;
    int b;

    ThisKeyword(int a,int b){
        this.a=a;
        this.b=b;
    }
     void display(){
        System.out.println(a+b);
    }
    public static void main(String[] args){
        ThisKeyword tk=new ThisKeyword(12,3);
        tk.display();
    }

}

