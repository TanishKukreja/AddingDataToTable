package practice.asigra;

import java.util.HashMap;

public class HashMapForCapitals {

    public static void main(String[] args) {
        HashMap<String, String> Capitals = new HashMap<String, String>();
        Capitals.put("Haryana", "Chandigarh");
        Capitals.put("Rajasthan", "Jaipur");
        System.out.println("This is for all");
        System.out.println(Capitals);
        System.out.println("This is for specific");
        System.out.println(Capitals.get("Haryana"));
    }
}
