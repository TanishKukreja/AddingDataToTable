package practice;

abstract class Animall{
    public abstract void animalSound();
    public void sleep(){
        System.out.println("zzz");
    }
        }
        class pig extends Animall{
    public void animalSound(){
        System.out.println("wee");
    }
        }
public class Abstract {
    public static void main(String[] args){
        pig myPig=new pig();
        myPig.animalSound();
        myPig.sleep();
    }
}
