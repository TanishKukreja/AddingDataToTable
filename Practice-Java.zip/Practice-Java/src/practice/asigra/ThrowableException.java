package practice.asigra;

public class ThrowableException {
    public static void checkAge(int age) {
        if (age >= 18) {
            System.out.println("Your age is passed u r eligible");
        } else {
            System.out.println("You must be 18");
        }
    }
    public static void main(String[] args) {
        checkAge(12);
    }
}
