package practice.asigra;

class Person {
    private String name;

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    private String lastName;

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        this.name = newName;
    }
}

public class Encapsulation {
    public static void main(String[] args) {
        Person myPerson = new Person();
        myPerson.setName("Tanish");
        myPerson.setLastName("Kukreja");

        System.out.println(myPerson.getName());
        System.out.println(myPerson.getLastName());
    }
}
