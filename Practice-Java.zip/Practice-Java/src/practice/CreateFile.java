package practice;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {
    public static void main(String[] args) {
        try {
            File myFile = new File(" 16Nov.txt");

            if (myFile.createNewFile()) {
                System.out.println("File is Created" + myFile.getName());
            } else if (myFile.exists()) {
                System.out.println("File already exists");
                throw new ArithmeticException();
            }
        } catch (IOException e) {
            System.out.println("AN error occured");
            e.printStackTrace();
        }
        try{
            FileWriter myWriter=new FileWriter("DataFile");
            myWriter.write("Hi iam new file which is written");
            myWriter.close();
            System.out.println("Success in written");
        }
        catch (IOException f){
            System.out.println("an error in written");
            f.printStackTrace();
        }
    }
}
