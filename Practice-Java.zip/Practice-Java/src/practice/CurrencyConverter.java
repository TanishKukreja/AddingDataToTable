package practice;

public class CurrencyConverter {
    double[] exchangeRates;

    void setExchangeRates(double[] rates) {
        exchangeRates = rates;

    }

    void printCurrencies() {
        System.out.println("\n rupee " + exchangeRates[0]);
        System.out.println("\n Dirhams " + exchangeRates[1]);
        System.out.println("\n Aus " + exchangeRates[2]);
    }

    public static void main(String[] args) {
        CurrencyConverter cc = new CurrencyConverter();
        double[] rates = {63.0, 3.0, 2.0};
        cc.setExchangeRates(rates);
        cc.printCurrencies();
    }
}
