package practice;

public class StaticMethod {
    static int a=10;
    int b=10;

    static void m1(){
        a=20;
        System.out.println("From m1");


    }
    public static void main(String[] args){
m1();
    }
}
