package practice;
import java.util.Scanner;

public class Animal {
    public void animalSound() {
        System.out.println("the animal makes sound");
    }
}

class Dog extends Animal {
    @Override
    public void animalSound() {
        System.out.println("bho bho");
    }
}

class Goat extends Animal {
    @Override
    public void animalSound() {
        System.out.println("hee");
    }
}
class Main{

    public static void main(String[] args){
        Animal myAnimal=new Animal();
        Animal myDog=new Dog();
        Animal myGoat=new Goat();
            myGoat.animalSound();
            myDog.animalSound();
            myAnimal.animalSound();
    }
}
